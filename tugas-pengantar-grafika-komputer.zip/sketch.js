function setup() {
  createCanvas(640, 480);
}

function draw() {
  background(123)
  fill(200, 100, 150);
  rect(100, 50,100,300)
}
